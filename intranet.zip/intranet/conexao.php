<?php

	$hostname = "localhost";
	$usuario = "root";
	$senha = "";
	$bancodedados = "intranet";

	$conn = mysqli_connect($hostname, $usuario, $senha, $bancodedados);
?>

<?php

	$listagemservidores = sprintf("SELECT nome, funcao, so, tipo, processador, memoria, disco, ip FROM servidores ");
    $dadosservidores = mysqli_query($conn,$listagemservidores);
    $informacaoservidores=mysqli_fetch_assoc($dadosservidores);
	$totalservidores = mysqli_num_rows($dadosservidores);
?>

<?php

	$listagemfinanceiro = sprintf("SELECT fornecedor, janeiro, fevereiro, marco, abril, maio, junho, julho, agosto, setembro, outubro, novembro, dezembro FROM financeiro ");
    $dadosfinanceiro = mysqli_query($conn,$listagemfinanceiro);
    $informacaofinanceiro=mysqli_fetch_assoc($dadosfinanceiro);
	$totalfinanceiro = mysqli_num_rows($dadosfinanceiro);
?>