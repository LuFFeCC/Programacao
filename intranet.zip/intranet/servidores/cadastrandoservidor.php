<?php
session_start();
?>
<!DOCTYPE html>

<html>
    <heade>
            <meta charset="utf-8">
            <title>Intranet - Mix</title>

            <!-- CSS STYLE-->
            <link rel="stylesheet" type="text/css" href="../css/style.css">
    <head>
    <body>
        

        <!-- INICIO DO CENTRO 1-->
    
        <div id="centroservidor1">
        	<br>
            <H1 style="text-align: center; color: white;">SERVIDORES</H1>
            <div id="botao">
                <a href="listagemservidores.php"><button class="btn third">LISTAR</button></a>
            </div>

            <div id="botao">
                <button class="btn third">EDITAR</button>
            </div>
        </div>
        <!-- FIM DO CENTRO 1-->

        <!-- INICIO DO CENTRO 2-->
        <div id="centrocadastrarservidor" style="color:white">
			<h1>Cadastrar Usuário</h1>
			<hr><br>
			<?php
				if(isset($_SESSION['msg'])){
					echo $_SESSION['msg'];
					unset($_SESSION['msg']);
				}
			?>

			<form method="POST" action="processa.php">
			<label>NOME: </label>
			<input type="text" name="nome" placeholder="Digite o nome completo" class="botaosv"><br><br>
			
			<label>FUNÇÃO: </label>
			<input type="text" name="funcao" placeholder="Digite a Função" class="botaosv"><br><br>

			<label>SO: </label>
			<input type="text" name="so" placeholder="Digite a Função" class="botaosv"><br><br>

			<label>TIPO: </label>
			<select id="tipo" name="tipo" class="botaosv">
				<option value="Virtual" class="botaosv">Virtual</option>
				<option value="Fisico">Fisico</option>
			</select>
			<!--<input type="text" name="tipo" placeholder="Digite o tipo" class="botaosv"><br><br>-->

			<label>PROCESSADOR: </label>
			<input type="text" name="processador" placeholder="Digite o Processador" class="botaosv" class="botaosv"><br><br>

			<label>MEMÓRIA: </label>
			<input type="text" name="memoria" placeholder="Digite a Quantidade de Memoria" class="botaosv"><br><br>

			<label>DISCO: </label>
			<input type="text" name="disco" placeholder="Digite o Tamanho do Disco" class="botaosv"><br><br>

			<label>IP: </label>
			<input type="text" name="ip" placeholder="xxx.xxx.xxx.xxx" class="botaosv"><br><br>
			
			<br>

			<input type="submit" value="Cadastrar" class="botaosv">
			<br><br><br>
		</form>

        </div>
        <!-- FIM DO CENTRO 2-->
	<br><br><br>
    </body>
</html>
