<?php
session_start();
include_once("../conexao.php");

$nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
$funcao = filter_input(INPUT_POST, 'funcao', FILTER_SANITIZE_STRING);
$so = filter_input(INPUT_POST, 'so', FILTER_SANITIZE_STRING);
$tipo = filter_input(INPUT_POST, 'tipo', FILTER_SANITIZE_STRING);
$processador = filter_input(INPUT_POST, 'processador', FILTER_SANITIZE_STRING);
$memoria = filter_input(INPUT_POST, 'memoria', FILTER_SANITIZE_STRING);
$disco = filter_input(INPUT_POST, 'disco', FILTER_SANITIZE_STRING);
$ip = filter_input(INPUT_POST, 'ip', FILTER_SANITIZE_STRING);


$result_usuario = "INSERT INTO servidores (nome, funcao, so, tipo, processador, memoria, disco, ip) VALUES ('$nome', '$funcao', '$so','$tipo', '$processador','$memoria','$disco', '$ip')";
$resultado_usuario = mysqli_query($conn, $result_usuario);

if(mysqli_insert_id($conn)){
	$_SESSION['msg'] = "<p style='color:green;'>Usuário cadastrado com sucesso</p>";
	header("Location: listagemservidores.php");
}else{
	$_SESSION['msg'] = "<p style='color:red;'>Usuário não foi cadastrado com sucesso</p>";
	header("Location: listagemservidores.php");
}


?>

<?php
session_start();
include_once("../conexao.php");

$ano = filter_input(INPUT_POST, 'ano', FILTER_SANITIZE_STRING);
$fornecedor = filter_input(INPUT_POST, 'fornecedor', FILTER_SANITIZE_STRING);
$janeiro = filter_input(INPUT_POST, 'janeiro', FILTER_SANITIZE_STRING);
$fevereiro = filter_input(INPUT_POST, 'fevereiro', FILTER_SANITIZE_STRING);
$marco = filter_input(INPUT_POST, 'marco', FILTER_SANITIZE_STRING);
$abril = filter_input(INPUT_POST, 'abril', FILTER_SANITIZE_STRING);
$maio = filter_input(INPUT_POST, 'maio', FILTER_SANITIZE_STRING);
$junho = filter_input(INPUT_POST, 'junho', FILTER_SANITIZE_STRING);
$julho = filter_input(INPUT_POST, 'julho', FILTER_SANITIZE_STRING);
$agosto = filter_input(INPUT_POST, 'agosto', FILTER_SANITIZE_STRING);
$setembro = filter_input(INPUT_POST, 'setembro', FILTER_SANITIZE_STRING);
$outubro = filter_input(INPUT_POST, 'outubro', FILTER_SANITIZE_STRING);
$novembro = filter_input(INPUT_POST, 'novembro', FILTER_SANITIZE_STRING);
$dezembro = filter_input(INPUT_POST, 'dezembro', FILTER_SANITIZE_STRING);


$result_usuario = "INSERT INTO financeiro (ano, fornecedor, janeiro, fevereiro, marco, abril, maio, junho, julho, agosto, setembro, outubro, novembro, dezembro) VALUES ('$ano', '$fornecedor', '$janeiro','$fevereiro', '$marco','$abril','$maio', '$junho', '$julho', '$agosto', '$setembro', '$outubro', '$novembro', '$dezembro')";
$resultado_usuario = mysqli_query($conn, $result_usuario);

if(mysqli_insert_id($conn)){
	$_SESSION['msg'] = "<p style='color:green;'>Usuário cadastrado com sucesso</p>";
	header("Location: ../financeiro/listagemfinanceiro.php");
}else{
	$_SESSION['msg'] = "<p style='color:red;'>Usuário não foi cadastrado com sucesso</p>";
	header("Location: ../financeiro/listagemfinanceiro.php");
}


?>