<html>
    <heade>
            <meta charset="utf-8">
            <title>Intranet - Mix</title>

            <!-- CSS STYLE-->
            <link rel="stylesheet" type="text/css" href="../css/style.css">
    <head>
    <body>
        <div id="cabecalho">
            <div id="iniciocabecalho">
                <a href="../index.php">
                    <img src="../img/se.png" height="100%" width="100%"/>
                </a>
            </div>
            <div id="meiocabecalho">INTRANET - MIX HOME CENTER</div>
            <div id="fimcabecalho"><img src="../img/th.png" height="100%" width="100%"></div>
        </div>
        <div id="cabecalho2"></div>
        <!-- FIM DO CABEÇACLHO -->


        <!-- INICIO DO INFRAME-->
        <div id="centroinframe">
            <iframe src="listagemservidores.php" title="description" width="99.71%" height="100%">
            
            </iframe>
        </div>
        <!-- FIM DO INFRAME --> 

        <!-- INICIO DO RODAPE-->
        <div id="rodape">
            <p style="color:white;" align="center">Todos os direitos reservados.</p>
        </div>
        <!-- FIM DO RODAPE-->
    </body>
</html>
