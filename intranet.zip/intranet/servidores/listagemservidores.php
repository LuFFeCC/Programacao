<?php
    session_start();
    include_once("../conexao.php");
?>

<html>
    <heade>
            <meta charset="utf-8">
            <title>Intranet - Mix</title>

            <!-- CSS STYLE-->
            <link rel="stylesheet" type="text/css" href="../css/style.css">
    <head>
    <body>
        

        <!-- INICIO DO CENTRO 1-->
    
        <div id="centroservidor1">
            <br>
            <H1 style="text-align: center; color: white;">SERVIDORES</H1>
            <div id="botao">
                <button class="btn third"><a href="cadastrandoservidor.php">CADASTRAR</a></button>
            </div>

            <div id="botao">
                <button class="btn third">EDITAR</button>
            </div>
        </div>
        <!-- FIM DO CENTRO 1-->

        <!-- INICIO DO CENTRO 2-->
        <div id="centroservidor2">
            <table border="3" style="border-collapse: collapse; background: blue;">
                <tr>
                    <th width="11%" ></th>
                    <th width="11%" style="text-align: center;">NOME </th>
                    <th width="11%" style="text-align: center;">FUNÇÃO </th>
                    <th width="11%" style="text-align: center;">SO </th>                    
                    <th width="11%" style="text-align: center;">TIPO </th>
                    <th width="11%" style="text-align: center;">PROCESSADOR</th>
                    <th width="11%" style="text-align: center;">MEMÓRIA</th>
                    <th width="11%" style="text-align: center;">DISCO</th>
                    <th width="11%" style="text-align: center;">IP</th>
                </tr>

            </table>


            <?php
                // se o número de resultados for maior que zero, mostra os dados
                if($totalservidores > 0) {
                    // inicia o loop que vai mostrar todos os dados
                do {
            ?>
            <table border="3" style="border-collapse: collapse">
                <tr>
                    <th width="11%" style="text-align: center;">Servidor: </th>
                    <td width="11%" style="text-align: center;"><?=$informacaoservidores['nome']?></td>
                    <td width="11%" style="text-align: center;"><?=$informacaoservidores['funcao']?></td>
                    <td width="11%" style="text-align: center;"><?=$informacaoservidores['so']?></td>                    
                    <td width="11%" style="text-align: center;"><?=$informacaoservidores['tipo']?></td>
                    <td width="11%" style="text-align: center;"><?=$informacaoservidores['processador']?></td>
                    <td width="11%" style="text-align: center;"><?=$informacaoservidores['memoria']?></td>
                    <td width="11%" style="text-align: center;"><?=$informacaoservidores['disco']?></td>
                    <td width="11%" style="text-align: center;"><?=$informacaoservidores['ip']?></td>
                </tr>
            <?php
                // finaliza o loop que vai mostrar os dados
                }while($informacaoservidores = mysqli_fetch_assoc($dadosservidores));
            // fim do if
                }
             ?>
            </table>


        </div>
        <!-- FIM DO CENTRO 2-->

        
    </body>
</html>
