<html>
    <heade>
            <meta charset="utf-8">
            <title>Intranet - Mix</title>

            <!-- CSS STYLE-->
            <link rel="stylesheet" type="text/css" href="css/style.css">
    <head>
    <body>
        <div id="cabecalho">
            <div id="iniciocabecalho">
                <a href="index.php">
                    <img src="img/se.png" height="100%" width="100%"/>
                </a>
            </div>
            <div id="meiocabecalho">INTRANET - MIX HOME CENTER</div>
            <div id="fimcabecalho"><a href="#"><img src="img/th.png" height="100%" width="100%"></a></div>
        </div>
        <div id="cabecalho2"></div>

        <!-- INICIO DO CENTRO 1-->

        <div id="centro1">
            <div id="imgcentro1">
                <p style="color:white;">Servidores</p><a href="servidores/servidores.php"><img src="img/servidores.gif"></a>
            </div>
            <div id="imgcentro1">
                <p style="color:white;">Equipamentos</p><a href="#"><img src="img/equi.png"></a>
            </div> 
            <div id="imgcentro1">
                <p style="color:white;">Financeiro</p><a href="financeiro/financeiro.php"><img src="img/financeiro.gif"></a>
            </div>           
        </div>
        <!-- FIM DO CENTRO 1-->

        <!-- INICIO DO CENTRO 2-->
        <div id="centro2">
            <div id="imgcentro2">
                <p style="color:white;">Backup</p><a href="#"><img src="img/backup.gif"></a> 
            </div>
            <div id="imgcentro2">
                <p style="color:white;">Sem Ideias</p><a href="#"><img src="img/semideia.gif"></a> 
            </div>
        </div>
        <!-- FIM DO CENTRO 2-->

        <!-- INICIO DO RODAPE-->
        <div id="rodape">
            
        </div>
        <!-- FIM DO RODAPE-->
    </body>
</html>
