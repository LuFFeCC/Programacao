<?php
    session_start();
    include_once("../conexao.php");
?>

<html>
    <heade>
            <meta charset="utf-8">
            <title>Intranet - Mix</title>

            <!-- CSS STYLE-->
            <link rel="stylesheet" type="text/css" href="../css/style.css">
    <head>

    <body>
        <div id="cabecalho">
            <div id="iniciocabecalho">
                <a href="../index.php">
                    <img src="../img/se.png" height="100%" width="100%"/>
                </a>
            </div>
            <div id="meiocabecalho">INTRANET - MIX HOME CENTER</div>
            <div id="fimcabecalho"><a href="#"><img src="../img/th.png" height="100%" width="100%"></a></div>
        </div>

         <!-- INICIO DO INFRAME-->
        <div id="centroinframe">
            <iframe src="listagemfinanceiro.php" title="description" width="99.5%" height="100%" frameborder="no">
            
            </iframe>
        </div>
        <!-- FIM DO INFRAME --> 


        <!-- INICIO DO RODAPE-->
        <div id="rodape">
            TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
        </div>
        <!-- FIM DO RODAPE-->
    </body>
</html>
