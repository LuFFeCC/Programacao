<?php
    session_start();
    include_once("../conexao.php");
?>

<html>
    <heade>
            <meta charset="utf-8">
            <title>Intranet - Mix</title>

            <!-- CSS STYLE-->
            <link rel="stylesheet" type="text/css" href="../css/style.css">
    <head>
    <body>
        
        <!-- INICIO DO CENTRO 1-->
    
        <div id="centrofinanceiro1">
            <br>
            <H1 style="text-align: center; color: white;">FINANCEIRO</H1>
            <div id="botao">
                <button class="btn third"><a href="cadastrofinanceiro.php">CADASTRAR </a></button>
            </div>

            <div id="botao">
                <button class="btn third">EDITAR</button>
            </div>
        </div>

        <!-- FIM DO CENTRO 1-->

        <!-- INICIO DO CENTRO 2-->
        <div id="centrolistarfinanceiro2">
            <table border="3" style="border-collapse: collapse; background: blue;">
                <tr>
                    <th width="6%" ></th>
                    <th width="6%" style="text-align: center;">JAN</th>
                    <th width="6%" style="text-align: center;">FEV</th>
                    <th width="6%" style="text-align: center;">MAR</th>                    
                    <th width="6%" style="text-align: center;">ABR</th>
                    <th width="6%" style="text-align: center;">MAI</th>
                    <th width="6%" style="text-align: center;">JUN</th>
                    <th width="6%" style="text-align: center;">JUL</th>
                    <th width="6%" style="text-align: center;">AGO</th>
                    <th width="6%" style="text-align: center;">SET</th>
                    <th width="6%" style="text-align: center;">OUT</th>
                    <th width="6%" style="text-align: center;">NOV</th>
                    <th width="6%" style="text-align: center;">DEZ</th>
                    <th width="6%" style="text-align: center;">TOTAL</th>
                </tr>

            </table>
            
            <?php
                // se o número de resultados for maior que zero, mostra os dados
                if($totalfinanceiro > 0) {
                    // inicia o loop que vai mostrar todos os dados
                do {

            ?>
           
            <table border="3" style="border-collapse: collapse">
                <tr>
                    <td width="6%" style="text-align: center;"><?=$informacaofinanceiro['fornecedor']?></td>
                    <td width="6%" style="text-align: center;">R$ <?=$informacaofinanceiro['janeiro']?></td>
                    <td width="6%" style="text-align: center;">R$ <?=$informacaofinanceiro['fevereiro']?></td>                    
                    <td width="6%" style="text-align: center;">R$ <?=$informacaofinanceiro['marco']?></td>
                    <td width="6%" style="text-align: center;">R$ <?=$informacaofinanceiro['abril']?></td>
                    <td width="6%" style="text-align: center;">R$ <?=$informacaofinanceiro['maio']?></td>
                    <td width="6%" style="text-align: center;">R$ <?=$informacaofinanceiro['junho']?></td>
                    <td width="6%" style="text-align: center;">R$ <?=$informacaofinanceiro['julho']?></td>
                    <td width="6%" style="text-align: center;">R$ <?=$informacaofinanceiro['agosto']?></td>
                    <td width="6%" style="text-align: center;">R$ <?=$informacaofinanceiro['setembro']?></td>
                    <td width="6%" style="text-align: center;">R$ <?=$informacaofinanceiro['outubro']?></td>
                    <td width="6%" style="text-align: center;">R$ <?=$informacaofinanceiro['novembro']?></td>
                    <td width="6%" style="text-align: center;">R$ <?=$informacaofinanceiro['dezembro']?></td>
                    <td width="6%" style="text-align: center;">R$ <?=$informacaofinanceiro['dezembro']?>+<?=$informacaofinanceiro['dezembro']?></td>

                </tr>
            <?php
                // finaliza o loop que vai mostrar os dados
                }while($informacaofinanceiro = mysqli_fetch_assoc($dadosfinanceiro));
            // fim do if
                }
             ?>
            </table>


        </div>
        <!-- FIM DO CENTRO 2-->

        
    </body>
</html>
