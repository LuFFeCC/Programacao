<?php
session_start();
?>
<!DOCTYPE html>

<html>
    <heade>
            <meta charset="utf-8">
            <title>Intranet - Mix</title>

            <!-- CSS STYLE-->
            <link rel="stylesheet" type="text/css" href="../css/style.css">
    <head>
    <body>
        

        <!-- INICIO DO CENTRO 1-->
    
        <div id="centroservidor1">

        	<br>
            <H1 style="text-align: center; color: white;">FINANCEIRO</H1>
            <div id="botao">
                <a href="listagemfinanceiro.php"><button class="btn third">LISTAR</button></a>
            </div>

            <div id="botao">
                <button class="btn third">EDITAR</button>
            </div>
        </div>
        <!-- FIM DO CENTRO 1-->

        <!-- INICIO DO CENTRO 2-->
        <div id="centrocadastrarfinanceiro" style="color:white">
			<h1>Cadastrar Financeiro</h1>
			<hr><br>
			<?php
				if(isset($_SESSION['msg'])){
					echo $_SESSION['msg'];
					unset($_SESSION['msg']);
				}
			?>

			<form method="POST" action="../servidores/processa.php" >

			<label>ANO: </label>
			<select id="ano" name="ano" class="botaosv">
				<option value="2019" >2019</option>
				<option value="2020">2020</option>
				<option value="2021">2021</option>
				<option value="2022">2022</option>
			</select><br><br>

			<label>FORNECEDOR: </label>
			<input type="text" name="fornecedor" placeholder="Digite o Fornecedor" class="botaosv"><br><br>
			
			<label>JANEIRO: </label>
			<input type="text" name="janeiro" placeholder="Valor Janeiro" class="botaosv"><br><br>

			<label>FEVEREIRO: </label>
			<input type="text" name="fevereiro" placeholder="Valor Fevereiro" class="botaosv"><br><br>

			<label>MARÇO: </label>
			<input type="text" name="marco" placeholder="Valor Março" class="botaosv"><br><br>

			<label>ABRIL: </label>
			<input type="text" name="abril" placeholder="Valor Abril" class="botaosv"><br><br>

			<label>MAIO: </label>
			<input type="text" name="maio" placeholder="Valor Maio " class="botaosv"><br><br>

			<label>JUNHO: </label>
			<input type="text" name="junho" placeholder="Valor Junho" class="botaosv"><br><br>

			<label>JULHO: </label>
			<input type="text" name="julho" placeholder="Valor Julho" class="botaosv"><br><br>

			<label>AGOSTO: </label>
			<input type="text" name="agosto" placeholder="Valor Agosto" class="botaosv"><br><br>

			<label>SETEMBRO: </label>
			<input type="text" name="setembro" placeholder="Valor Setembro" class="botaosv"><br><br>

			<label>OUTUBRO: </label>
			<input type="text" name="outubro" placeholder="Valor Outubro" class="botaosv"><br><br>

			<label>NOVEMBRO: </label>
			<input type="text" name="novembro" placeholder="Valor Novembro" class="botaosv"><br><br>

			<label>DEZEMBRO: </label>
			<input type="text" name="dezembro" placeholder="Valor Dezembro" class="botaosv"><br><br>
			
			<br>

			<input type="submit" value="Cadastrar" class="botaosv">
			<br><br><br>
		</form>

        </div>
        <!-- FIM DO CENTRO 2-->
	<br><br><br>
    </body>
</html>
